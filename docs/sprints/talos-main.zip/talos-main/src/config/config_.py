from datetime import timedelta

from pydantic import BaseModel, SecretStr, SecretBytes
from pydantic_settings import BaseSettings, SettingsConfigDict, PydanticBaseSettingsSource, YamlConfigSettingsSource


def is_pytest() -> bool:
    import os
    return "IS_TEST" in os.environ


class OAuthClient(BaseModel):
    client_id: str
    client_secret: SecretStr
    api_base_url: str
    access_token_url: str
    authorize_url: str
    server_metadata_url: str = None
    client_kwargs: dict = {}


class AuthConfig(BaseModel):
    oauth_clients: dict[str, OAuthClient] = {}

    totp_valid_window: int = 1

    jwe_secret: SecretBytes
    jwt_header: dict

    sudo_max_age: timedelta = timedelta(minutes=10)
    session_max_age: timedelta = timedelta(days=30)
    session_refresh_threshold: timedelta = timedelta(minutes=10)
    password_reset_token_expiry: timedelta = timedelta(hours=1)

    session_cookie_key: str = "user_session"
    session_cookie_secure: bool = True

    permission_bitstring_length: int = 64

    model_config = SettingsConfigDict(
        val_json_bytes="base64"
    )


class MinIOConfig(BaseModel):
    internal_endpoint: str = "127.0.0.1:9000"
    public_endpoint: str = "127.0.0.1:9000"
    access_key: str = "minioadmin"
    secret_key: SecretStr = SecretStr("minioadmin")
    secure: bool = False
    bucket: str = "talos"
    max_file_size: int = 50 * 1024 * 1024  # 50 MiB


class FilesConfig(BaseModel):
    max_size: int = 50 * 1024 * 1024  # 50 MiB

    # Allowed MIME types for uploads
    allowed_mime_types: set[str] = {
        # Documents
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
        "text/markdown",
        # Images
        "image/png",
        "image/jpeg",
        "image/webp",
    }

    document_mime_types: set[str] = {
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
        "text/markdown",
    }

    image_mime_types: set[str] = {
        "image/png",
        "image/jpeg",
        "image/webp",
        "image/gif",
        "image/bmp",
        "image/tiff",
        "image/heic",
        "image/heif",
        "image/avif",
    }

    video_mime_types: set[str] = {
        "video/mp4",
        "video/webm",
        "video/quicktime",
        "video/ogg",
        "video/x-msvideo",
        "video/x-matroska",
        "video/x-m4v",
        "video/mpeg",
        "video/3gpp",
    }

    # Chat attachments: documents + images + videos; never RAG-indexed.
    attachment_max_size: int = 200 * 1024 * 1024  # 200 MiB (videos)

    thumbnail_size: tuple[int, int] = (300, 300)


class RedisConfig(BaseModel):
    host: str = "localhost"
    port: int = 6379
    database: int = 0
    password: SecretStr = ""
    username: str = ""

    @property
    def url(self) -> str:
        auth_part = f"{self.username}:{self.password.get_secret_value()}@" if self.username and self.password else ""
        return f"redis://{auth_part}{self.host}:{self.port}/{self.database}"


class PushConfig(BaseModel):
    """Web Push configuration for VAPID."""
    vapid_private_key: str
    vapid_public_key: str
    vapid_subject: str


class JiraConfig(BaseModel):
    """Jira Cloud integration (read/process tickets of a configurable board)."""
    base_url: str  # e.g. https://yourorg.atlassian.net
    email: str
    api_token: SecretStr
    project_key: str  # default project, e.g. "TAL"
    board_id: str | None = None  # optional default board id


class GithubConfig(BaseModel):
    """GitHub integration (implement tickets / open PRs in a configurable repo)."""
    api_url: str = "https://api.github.com"
    token: SecretStr
    owner: str
    repo: str
    default_base_branch: str = "main"


class SlackConfig(BaseModel):
    """Slack bot integration."""
    bot_token: SecretStr  # xoxb-...
    signing_secret: SecretStr
    app_token: SecretStr | None = None  # xapp-..., socket mode (local dev)
    socket_mode: bool = False
    # Minimal identity mapping: slack_user_id -> Talos user uuid (string).
    user_map: dict[str, str] = {}
    default_talos_user_id: str  # fallback Talos user for unmapped Slack users


class BotConfig(BaseModel):
    """Identity and scope the embedded agent uses to act inside Talos."""
    bot_user_id: str  # Talos service-user uuid (message sender)
    default_workspace_id: str  # workspace the bot operates in
    default_channel_id: str  # channel the bot mirrors Slack into
    rag_collection: str = "documents_v2"


class McpConfig(BaseModel):
    """FastMCP server transport settings."""
    host: str = "0.0.0.0"
    port: int = 8001
    transport: str = "streamable-http"  # or "sse"


class DatabaseConfig(BaseModel):
    protocol: str = "postgresql+psycopg"
    async_protocol: str = "postgresql+psycopg"
    host: str
    port: int = 5432
    name: str
    user: str
    password: SecretStr

    @property
    def url(self) -> str:
        return f"{self.protocol}://{self.user}:{self.password.get_secret_value()}@{self.host}:{self.port}/{self.name}"

    @property
    def async_url(self) -> str:
        return f"{self.async_protocol}://{self.user}:{self.password.get_secret_value()}@{self.host}:{self.port}/{self.name}"


class Config(BaseSettings):
    is_test: bool = False
    app_name: str = "Talos"
    app_host: str
    app_port: int

    database: DatabaseConfig = None

    auth: AuthConfig = None
    minio: MinIOConfig = MinIOConfig()
    redis: RedisConfig = RedisConfig()
    files: FilesConfig = FilesConfig()
    push: PushConfig | None = None

    jira: JiraConfig | None = None
    github: GithubConfig | None = None
    slack: SlackConfig | None = None
    bot: BotConfig | None = None
    mcp: McpConfig = McpConfig()

    model_config = SettingsConfigDict(
        env_file='.env',
        env_nested_delimiter="__",
        extra="ignore",
        yaml_file="config/config.yaml"
    )

    @classmethod
    def settings_customise_sources(
            cls,
            settings_cls: type[BaseSettings],
            init_settings: PydanticBaseSettingsSource,
            env_settings: PydanticBaseSettingsSource,
            dotenv_settings: PydanticBaseSettingsSource,
            file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            # override during pytest
            *([YamlConfigSettingsSource(
                settings_cls,
                yaml_file="config/config.test.yaml",
                deep_merge=True
            )] if is_pytest() else ()),
            env_settings,
            dotenv_settings,
            YamlConfigSettingsSource(settings_cls),
            file_secret_settings,
        )
